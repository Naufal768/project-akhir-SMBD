<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "new_katering";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$editData = null;

// Jika tombol Edit diklik
if (isset($_GET['edit_id'])) {
    $edit_id = $_GET['edit_id'];
    $result = $conn->query("SELECT * FROM pembayaran WHERE id_pembayaran = '$edit_id'");
    if ($result && $result->num_rows > 0) {
        $editData = $result->fetch_assoc();
    }
}

// Jika form edit disubmit
if (isset($_POST['submit_edit'])) {
    // Ambil data dari form
    $id_pembayaran = $_POST['id_pembayaran'];
    $metode_pembayaran = $_POST['metode_pembayaran'];
    $total = $_POST['total'];
    $id_pesanan = $_POST['id_pesanan'];

    // Update data manual ke tabel pembayaran
    $updateQuery = "UPDATE pembayaran SET 
                    metode_pembayaran = '$metode_pembayaran',
                    total = '$total',
                    id_pesanan = '$id_pesanan'
                    WHERE id_pembayaran = '$id_pembayaran'";

    if ($conn->query($updateQuery) === TRUE) {
        // Jalankan stored procedure untuk update status menjadi 'Lunas'
        $call = $conn->query("CALL update_pembayaran_masif()");
        if ($call) {
            echo "<script>
                    alert('Data berhasil diedit dan status diperbarui!');
                    window.location.href = '" . $_SERVER['PHP_SELF'] . "';
                  </script>";
            exit;
        } else {
            echo "Gagal memanggil prosedur: " . $conn->error;
        }
    } else {
        echo "Gagal mengupdate data: " . $conn->error;
    }
}

// Ambil data yang Belum Lunas
$result_belum = $conn->query("SELECT * FROM pembayaran WHERE status_bayar = 'Belum Lunas'");

// Ambil semua data pembayaran
$result_semua = $conn->query("SELECT * FROM pembayaran");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Data Pembayaran</title>
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        body {
            background: linear-gradient(to right, #e0f7fa, #ffffff);
        }
    </style>
</head>
<body>

<div class="container py-4">

    <a href="index.php" class="btn btn-secondary mb-4"><i class="bi bi-house-door-fill me-1"></i> Beranda</a>

    <div class="mb-5">
        <h3 class="text-danger"><i class="bi bi-exclamation-octagon-fill me-2"></i>Pembayaran Belum Lunas</h3>
        <?php if ($result_belum->num_rows > 0): ?>
        <div class="table-responsive">
        <table class="table table-bordered table-striped align-middle">
            <thead class="table-light">
                <tr>
                    <th>ID Pembayaran</th>
                    <th>Metode Pembayaran</th>
                    <th>Total</th>
                    <th>Status</th>
                    <th>ID Pesanan</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
            <?php while($row = $result_belum->fetch_assoc()): ?>
                <tr>
                    <td><?= $row['id_pembayaran'] ?></td>
                    <td><?= $row['metode_pembayaran'] ?></td>
                    <td><?= $row['total'] ?></td>
                    <td><span class="badge bg-danger"><?= $row['status_bayar'] ?></span></td>
                    <td><?= $row['id_pesanan'] ?></td>
                    <td>
                        <a href="?edit_id=<?= $row['id_pembayaran'] ?>" class="btn btn-warning btn-sm">
                            <i class="bi bi-pencil-square"></i> Edit
                        </a>
                    </td>
                </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
        </div>
        <?php else: ?>
            <p class="text-muted">Tidak ada pembayaran yang belum lunas.</p>
        <?php endif; ?>
    </div>

    <?php if ($editData): ?>
    <hr>
    <h3><i class="bi bi-pencil-fill me-2 text-primary"></i>Edit Data Pembayaran</h3>
    <form method="POST" class="mt-3">
        <div class="row mb-3">
            <div class="col-md-6">
                <label class="form-label">ID Pembayaran:</label>
                <input type="text" name="id_pembayaran" class="form-control" value="<?= $editData['id_pembayaran'] ?>" readonly>
            </div>
            <div class="col-md-6">
                <label class="form-label">Metode Pembayaran:</label>
                <input type="text" name="metode_pembayaran" class="form-control" value="<?= $editData['metode_pembayaran'] ?>">
            </div>
        </div>
        <div class="row mb-3">
            <div class="col-md-6">
                <label class="form-label">Total:</label>
                <input type="number" name="total" class="form-control" value="<?= $editData['total'] ?>">
            </div>
            <div class="col-md-6">
                <label class="form-label">ID Pesanan:</label>
                <input type="text" name="id_pesanan" class="form-control" value="<?= $editData['id_pesanan'] ?>">
            </div>
        </div>
        <button type="submit" name="submit_edit" class="btn btn-success">
            <i class="bi bi-save-fill me-1"></i> Simpan & Update Lunas
        </button>
    </form>
    <?php endif; ?>

    <hr class="my-5">

    <h3><i class="bi bi-clipboard-data-fill me-2 text-success"></i>Semua Data Pembayaran</h3>
    <?php if ($result_semua->num_rows > 0): ?>
    <div class="table-responsive">
    <table class="table table-bordered align-middle">
        <thead class="table-light">
            <tr>
                <th>ID Pembayaran</th>
                <th>Metode Pembayaran</th>
                <th>Total</th>
                <th>Status</th>
                <th>ID Pesanan</th>
            </tr>
        </thead>
        <tbody>
        <?php while($row = $result_semua->fetch_assoc()): ?>
            <tr class="<?= $row['status_bayar'] == 'Lunas' ? 'table-success' : 'table-danger' ?>">
                <td><?= $row['id_pembayaran'] ?></td>
                <td><?= $row['metode_pembayaran'] ?></td>
                <td><?= $row['total'] ?></td>
                <td>
                    <span class="badge <?= $row['status_bayar'] == 'Lunas' ? 'bg-success' : 'bg-danger' ?>">
                        <?= $row['status_bayar'] ?>
                    </span>
                </td>
                <td><?= $row['id_pesanan'] ?></td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
    </div>
    <?php else: ?>
        <p class="text-muted">Tidak ada data pembayaran.</p>
    <?php endif; ?>

</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>


<?php 
$conn->close(); 
?>
