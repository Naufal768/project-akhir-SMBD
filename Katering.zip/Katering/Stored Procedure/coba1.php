<?php
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "new_katering"; // ganti sesuai nama database Anda

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Proses jika form disubmit
$hasil = [];
if (isset($_POST['submit'])) {
    $id_pelanggan = $_POST['id_pelanggan'];

    // Panggil stored procedure
    $stmt = $conn->prepare("CALL get_pesanan_by_pelanggan(?)");
    $stmt->bind_param("i", $id_pelanggan);
    $stmt->execute();
    $result = $stmt->get_result();

    // Ambil hasil
    while ($row = $result->fetch_assoc()) {
        $hasil[] = $row;
    }

    // Tutup prosedur dan statement
    $stmt->close();
    $conn->next_result(); // penting untuk membersihkan hasil prosedur sebelumnya
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Data Pesanan per Pelanggan</title>
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #f0f8ff, #ffe4f1);
            font-family: 'Segoe UI', sans-serif;
            padding-top: 80px;
        }

        .sticky-topbar {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 999;
            background-color: #ffffff;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            padding: 12px 24px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .card-custom {
            background: white;
            padding: 30px;
            border-radius: 1rem;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
        }

        h2, h3, h4 {
            font-weight: bold;
            color: #333;
        }

        th {
            background-color: #0d6efd;
            color: white;
        }

        table {
            margin-top: 20px;
        }

        .form-select {
            max-width: 400px;
            margin: 0 auto;
        }

        .btn-back {
            font-weight: bold;
        }

        .alert-info {
            margin-top: 20px;
        }
    </style>
</head>
<body>

    <!-- Sticky Top Bar -->
    <div class="sticky-topbar">
        <h5 class="mb-0"><i class="bi bi-person-circle"></i> Data Pesanan Pelanggan</h5>
        <a href="index.php" class="btn btn-warning btn-sm btn-back"><i class="bi bi-arrow-left-circle"></i> Kembali</a>
    </div>

    <div class="container mt-4">
        <div class="card card-custom">
            <h2 class="text-center"><i class="bi bi-list-check"></i> Pilih Pelanggan</h2>

            <form method="POST" action="" class="text-center mt-4">
                <label for="id_pelanggan" class="form-label fw-semibold">Pelanggan:</label>
                <div class="mb-3">
                    <select name="id_pelanggan" required class="form-select d-inline-block">
                        <option value="">-- Pilih --</option>
                        <?php
                        // Ambil data pelanggan
                        $sql = "SELECT id_pelanggan, nama_pelanggan FROM pelanggan";
                        $res = $conn->query($sql);
                        while ($row = $res->fetch_assoc()) {
                            echo "<option value='".$row['id_pelanggan']."'>".$row['id_pelanggan']." - ".$row['nama_pelanggan']."</option>";
                        }
                        ?>
                    </select>
                </div>
                <input type="submit" name="submit" value="Lihat Pesanan" class="btn btn-primary">
            </form>

            <?php if (!empty($hasil)) : ?>
                <h4 class="mt-5"><i class="bi bi-clipboard-data"></i> Daftar Pesanan</h4>
                <div class="table-responsive">
                    <table class="table table-bordered table-striped mt-3">
                        <thead>
                            <tr>
                                <th>ID Pesanan</th>
                                <th>Nama Menu</th>
                                <th>Tanggal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($hasil as $data) : ?>
                                <tr>
                                    <td><?= htmlspecialchars($data['id_pesanan']) ?></td>
                                    <td><?= htmlspecialchars($data['nama_menu']) ?></td>
                                    <td><?= htmlspecialchars($data['tanggal']) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php elseif (isset($_POST['submit'])) : ?>
                <div class="alert alert-info text-center" role="alert">
                    <i class="bi bi-info-circle"></i> Tidak ada pesanan ditemukan untuk pelanggan ini.
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
