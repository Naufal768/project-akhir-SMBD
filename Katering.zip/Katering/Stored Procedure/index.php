<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Dashboard Katering</title>
  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Bootstrap Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Dancing+Script&family=Playfair+Display:wght@600&display=swap" rel="stylesheet">

  <style>
    body {
      background: linear-gradient(135deg, #e0f7fa, #fff3e0);
      font-family: 'Segoe UI', sans-serif;
      min-height: 100vh;
    }

    header.sticky-top {
      background: linear-gradient(to right, #ffffff, #f0f0f0);
      padding: 15px 20px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
      z-index: 1030;
    }

    h2 {
      font-weight: bold;
      margin: 0;
      color: #333;
    }

    .card-custom {
      transition: all 0.3s ease;
      border: none;
      border-radius: 1rem;
      background: #fff;
      box-shadow: 0 8px 20px rgba(0,0,0,0.1);
    }

    .card-custom:hover {
      transform: translateY(-8px);
      box-shadow: 0 12px 28px rgba(0,0,0,0.15);
    }

    .card-custom i {
      font-size: 2.8rem;
      margin-bottom: 12px;
      color: #0d6efd;
    }

    .card-title {
      font-size: 1.3rem;
      font-weight: 600;
    }

    .card-text {
      font-size: 0.95rem;
      color: #555;
    }

    a.card-link {
      text-decoration: none;
      color: inherit;
    }

    .container-cards {
      padding: 60px 20px 40px;
    }

    .btn-top {
      font-size: 0.9rem;
    }
  </style>
</head>
<body>

  <!-- Sticky Header with Button -->
  <header class="sticky-top d-flex justify-content-between align-items-center">
    <h2><i class="bi bi-house-door-fill"></i> Dashboard Katering</h2>
    <a href="../index.php" class="btn btn-warning btn-sm btn-top">
      <i class="bi bi-arrow-left"></i> Kembali
    </a>
  </header>

  <div class="container container-cards">
    <div class="row g-4 justify-content-center">

      <!-- Card 1 -->
      <div class="col-md-4 col-lg-3">
        <a href="coba1.php" class="card-link">
          <div class="card card-custom text-center p-4">
            <i class="bi bi-clipboard-data"></i>
            <h5 class="card-title">Stored Procedure Pesanan</h5>
            <p class="card-text">Lihat Pesanan Berdasarkan Pelanggan</p>
          </div>
        </a>
      </div>

      <!-- Card 2 -->
      <div class="col-md-4 col-lg-3">
        <a href="coba5.php" class="card-link">
          <div class="card card-custom text-center p-4 bg-light">
            <i class="bi bi-cash-coin"></i>
            <h5 class="card-title">Stored Procedure Total</h5>
            <p class="card-text">Lihat Total Pendapatan berdasarkan Status</p>
          </div>
        </a>
      </div>

      <!-- Card 3 -->
      <div class="col-md-4 col-lg-3">
        <a href="coba2.php" class="card-link">
          <div class="card card-custom text-center p-4">
            <i class="bi bi-journal-plus"></i>
            <h5 class="card-title">Stored Procedure Insert Pesanan (3)</h5>
            <p class="card-text">After Insert (Relasi 3 Tabel) Looping</p>
          </div>
        </a>
      </div>

      <!-- Card 4 -->
      <div class="col-md-4 col-lg-3">
        <a href="coba3.php" class="card-link">
          <div class="card card-custom text-center p-4 bg-light">
            <i class="bi bi-credit-card-2-front"></i>
            <h5 class="card-title">Stored Procedure Pembayaran</h5>
            <p class="card-text">Ganti Status Bayar (Lunas) Jika Total Bayar > Rp50</p>
          </div>
        </a>
      </div>

      <!-- Card 5 -->
      <div class="col-md-4 col-lg-3">
        <a href="coba4.php" class="card-link">
          <div class="card card-custom text-center p-4">
            <i class="bi bi-graph-up-arrow"></i>
            <h5 class="card-title">Stored Procedure Pendapatan</h5>
            <p class="card-text">Rekap Pendapatan Berdasarkan Tanggal</p>
          </div>
        </a>
      </div>

    </div>
  </div>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
