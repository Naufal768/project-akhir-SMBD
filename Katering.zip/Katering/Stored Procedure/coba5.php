<?php
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "new_katering"; // Ganti sesuai database Anda

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$hasil = null;
$statusDipilih = '';

if (isset($_POST['submit'])) {
    $statusDipilih = $_POST['status'];

    // Panggil stored procedure
    $query = "CALL get_total_pendapatan_by_status('$statusDipilih')";
    $result = mysqli_query($conn, $query);

    if ($result) {
        $hasil = mysqli_fetch_assoc($result);
        mysqli_next_result($conn); // Membersihkan sisa result set
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Total Pendapatan Berdasarkan Status</title>
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #f0f8ff, #ffe4f1);
            font-family: 'Segoe UI', sans-serif;
            padding-top: 80px;
        }

        .sticky-topbar {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 999;
            background-color: #ffffff;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            padding: 12px 24px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .card-custom {
            background: white;
            padding: 30px;
            border-radius: 1rem;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
        }

        h2, h3, h4 {
            font-weight: bold;
            color: #333;
        }

        th {
            background-color: #0d6efd;
            color: white;
        }

        .table {
            margin-top: 20px;
        }

        .btn-back {
            font-weight: bold;
        }

        .form-select {
            max-width: 400px;
            margin: 0 auto;
        }

        .alert-info {
            margin-top: 20px;
        }
    </style>
</head>
<body>

    <!-- Sticky Top Bar -->
    <div class="sticky-topbar">
        <h5 class="mb-0"><i class="bi bi-cash-stack"></i> Laporan Pendapatan</h5>
        <a href="index.php" class="btn btn-warning btn-sm btn-back"><i class="bi bi-arrow-left-circle"></i> Kembali</a>
    </div>

    <div class="container mt-4">
        <div class="card card-custom">
            <h2 class="text-center"><i class="bi bi-filter-circle"></i> Filter Pendapatan Berdasarkan Status</h2>

            <form method="post" action="" class="text-center mt-4">
                <label for="status" class="form-label fw-semibold">Pilih Status Pembayaran:</label>
                <div class="mb-3">
                    <select name="status" required class="form-select d-inline-block">
                        <option value="">-- Pilih Status --</option>
                        <option value="Lunas" <?= ($statusDipilih == 'Lunas') ? 'selected' : '' ?>>Lunas</option>
                        <option value="Belum Lunas" <?= ($statusDipilih == 'Belum Lunas') ? 'selected' : '' ?>>Belum Lunas</option>
                    </select>
                </div>
                <input type="submit" name="submit" value="Lihat Total" class="btn btn-primary">
            </form>

            <?php if ($hasil): ?>
                <h4 class="mt-5"><i class="bi bi-graph-up"></i> Hasil Total Pendapatan</h4>
                <div class="table-responsive">
                    <table class="table table-bordered table-striped mt-3">
                        <thead>
                            <tr>
                                <th>Status Pembayaran</th>
                                <th>Total Pendapatan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><?= htmlspecialchars($hasil['status_yang_dihitung']) ?></td>
                                <td>Rp <?= number_format($hasil['total_pembayaran'], 0, ',', '.') ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            <?php elseif (isset($_POST['submit'])): ?>
                <div class="alert alert-info text-center" role="alert">
                    <i class="bi bi-info-circle"></i> Tidak ada data untuk status tersebut.
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
