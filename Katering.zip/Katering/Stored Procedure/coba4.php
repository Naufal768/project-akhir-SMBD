<?php
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "new_katering"; // Ganti sesuai database Anda

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
} // ganti sesuai file koneksi Anda

// Ambil daftar tanggal unik dari tabel pesanan
$tanggalList = [];
$tanggalQuery = mysqli_query($conn, "SELECT DISTINCT tanggal FROM pesanan ORDER BY tanggal DESC");
while ($row = mysqli_fetch_assoc($tanggalQuery)) {
    $tanggalList[] = $row['tanggal'];
}

// Proses jika form dikirim
$hasil = [];
if (isset($_POST['submit'])) {
    $tgl = $_POST['tanggal'];

    $query = "CALL get_rekap_tanggal('$tgl')";
    $result = mysqli_query($conn, $query);

    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $hasil[] = $row;
        }
        mysqli_next_result($conn); // Penting untuk membersihkan sisa result set
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Rekap Tanggal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(to right, #f8f9fa, #e0f7fa);
            min-height: 100vh;
        }
        .btn-top {
            position: fixed;
            bottom: 30px;
            right: 30px;
            z-index: 999;
            background-color: #198754;
            color: white;
            padding: 12px 18px;
            border-radius: 50px;
            font-size: 18px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.2);
            text-decoration: none;
        }
        .btn-top:hover {
            background-color: #157347;
            color: white;
        }
    </style>
</head>
<body>

<div class="container py-5">
    <h2 class="mb-4 text-primary"><i class="fa-solid fa-calendar-days"></i> Rekap Pesanan Berdasarkan Tanggal</h2>

    <form method="post" action="" class="row g-3 align-items-end mb-4">
        <div class="col-md-6">
            <label for="tanggal" class="form-label">Pilih Tanggal:</label>
            <select name="tanggal" id="tanggal" class="form-select" required>
                <option value="">-- Pilih Tanggal --</option>
                <?php foreach ($tanggalList as $tgl): ?>
                    <option value="<?= $tgl ?>" <?= (isset($_POST['tanggal']) && $_POST['tanggal'] == $tgl) ? 'selected' : '' ?>>
                        <?= $tgl ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-3">
            <button type="submit" name="submit" class="btn btn-primary">
                <i class="fa-solid fa-filter"></i> Tampilkan
            </button>
        </div>
    </form>

    <?php if (!empty($hasil)): ?>
        <div class="table-responsive">
            <h4 class="text-success mb-3"><i class="fa-solid fa-table-list"></i> Hasil Rekap</h4>
            <table class="table table-bordered table-striped">
                <thead class="table-light">
                    <tr>
                        <th><i class="fa-solid fa-hashtag"></i> ID Pesanan</th>
                        <th><i class="fa-solid fa-user"></i> Nama Pelanggan</th>
                        <th><i class="fa-solid fa-utensils"></i> Menu</th>
                        <th><i class="fa-solid fa-credit-card"></i> Status Bayar</th>
                        <th><i class="fa-solid fa-money-bill-wave"></i> Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($hasil as $data): ?>
                        <tr>
                            <td><?= $data['id_pesanan'] ?></td>
                            <td><?= $data['nama_pelanggan'] ?></td>
                            <td><?= $data['nama_menu'] ?></td>
                            <td><?= $data['status_bayar'] ?></td>
                            <td>Rp <?= number_format($data['total'], 0, ',', '.') ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php elseif (isset($_POST['submit'])): ?>
        <div class="alert alert-warning mt-4">
            <i class="fa-solid fa-circle-info"></i> Tidak ada data untuk tanggal tersebut.
        </div>
    <?php endif; ?>
</div>

<!-- Tombol Kembali ke Atas -->
<a href="index.php" class="btn-top">
    <i class="fa-solid fa-house-chimney"></i>
</a>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

