<?php
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "new_katering"; // Ganti sesuai database Anda

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Tangani form submit
$pesan = "";
if (isset($_POST['submit'])) {
    $id_pelanggan = $_POST['id_pelanggan'];
    $id_menu = $_POST['id_menu'];
    $metode = $_POST['metode'];

    // Panggil prosedur
    $stmt = $conn->prepare("CALL insert_pesanan_dan_pembayaran(?, ?, ?)");
    $stmt->bind_param("iis", $id_pelanggan, $id_menu, $metode);

    if ($stmt->execute()) {
        $pesan = "✅ Pesanan dan pembayaran berhasil ditambahkan.";
    } else {
        $pesan = "❌ Gagal menambahkan: " . $conn->error;
    }

    $stmt->close();
    $conn->next_result(); // Penting untuk membersihkan hasil prosedur sebelumnya
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Tambah Pesanan dan Pembayaran</title>
    <!-- Tambahkan link Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Tambahkan latar belakang gradasi */
        body {
            background: linear-gradient(135deg, #ffecd2 0%, #fcb69f 100%);
            min-height: 100vh;
            padding-top: 40px;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0px 5px 20px rgba(0,0,0,0.1);
        }
        .btn-back {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>

<div class="container col-md-6">
    <!-- Tombol kembali ke index.php -->
    <a href="index.php" class="btn btn-secondary btn-back">← Kembali ke Beranda</a>

    <h2 class="mb-4 text-center">Form Tambah Pesanan dan Pembayaran</h2>

    <!-- Tampilkan pesan berhasil/gagal -->
    <?php if ($pesan) echo "<div class='alert alert-info'>$pesan</div>"; ?>

    <form method="POST">
        <!-- Pilih pelanggan -->
        <div class="mb-3">
            <label for="id_pelanggan" class="form-label">Pelanggan:</label>
            <select name="id_pelanggan" class="form-select" required>
                <option value="">-- Pilih Pelanggan --</option>
                <?php
                $result = $conn->query("SELECT id_pelanggan, nama_pelanggan FROM pelanggan");
                while ($row = $result->fetch_assoc()) {
                    echo "<option value='{$row['id_pelanggan']}'>{$row['id_pelanggan']} - {$row['nama_pelanggan']}</option>";
                }
                ?>
            </select>
        </div>

        <!-- Pilih menu -->
        <div class="mb-3">
            <label for="id_menu" class="form-label">Menu:</label>
            <select name="id_menu" class="form-select" required>
                <option value="">-- Pilih Menu --</option>
                <?php
                $result = $conn->query("SELECT id_menu, nama_menu, harga FROM menu");
                while ($row = $result->fetch_assoc()) {
                    echo "<option value='{$row['id_menu']}'>{$row['nama_menu']} - Rp " . number_format($row['harga'], 0, ',', '.') . "</option>";
                }
                ?>
            </select>
        </div>

        <!-- Pilih metode pembayaran -->
        <div class="mb-4">
            <label for="metode" class="form-label">Metode Pembayaran:</label>
            <select name="metode" class="form-select" required>
                <option value="">-- Pilih Metode --</option>
                <option value="Tunai">Tunai</option>
                <option value="Transfer">Transfer</option>
                <option value="QRIS">QRIS</option>
                <option value="E-Wallet">E-Wallet</option>
            </select>
        </div>

        <!-- Tombol submit -->
        <div class="text-center">
            <input type="submit" name="submit" class="btn btn-primary px-4" value="💾 Simpan Pesanan">
        </div>
    </form>
</div>

<!-- Tambahkan JS Bootstrap (opsional untuk komponen interaktif) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
