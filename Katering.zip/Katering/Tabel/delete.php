<?php
require_once '../koneksi.php';

$table = $_GET['tabel'];
$id    = $_GET['id'];

$field = mysqli_fetch_field_direct(mysqli_query($conn, "SELECT * FROM $table LIMIT 1"), 0)->name;

$query = "DELETE FROM $table WHERE $field = '$id'";
if (mysqli_query($conn, $query)) {
    header("Location: ../index.php");
    exit;
} else {
    echo "Gagal menghapus data.";
}
?>
