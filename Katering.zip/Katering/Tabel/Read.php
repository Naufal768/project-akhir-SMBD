<?php
include '../koneksi.php';

$tabels = ['pelanggan', 'pesanan', 'menu', 'kategori', 'pembayaran'];

function getKolom($conn, $namaTabel) {
    $result = mysqli_query($conn, "DESCRIBE $namaTabel");
    $columns = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $columns[] = $row['Field'];
    }
    return $columns;
}

function getMenuOptions($conn) {
    $result = mysqli_query($conn, "SELECT id_menu, nama_menu FROM menu");
    $options = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $options[] = $row;
    }
    return $options;
}

function getKategoriOptions($conn) {
    $result = mysqli_query($conn, "SELECT id_kategori, nama_kategori FROM kategori");
    $options = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $options[] = $row;
    }
    return $options;
}

function getPesananOptionsWithHarga($conn) {
    $sql = "SELECT p.id_pesanan, m.harga 
            FROM pesanan p 
            JOIN menu m ON p.id_menu = m.id_menu
            WHERE p.id_pesanan NOT IN (SELECT id_pesanan FROM pembayaran)
            ORDER BY p.id_pesanan ASC";

    $result = mysqli_query($conn, $sql);
    $options = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $options[] = $row;
    }
    return $options;
}

function getPelangganOptions($conn) {
    $result = mysqli_query($conn, "SELECT id_pelanggan, nama_pelanggan FROM pelanggan");
    $options = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $options[] = $row;
    }
    return $options;
}

function tampilkanTabel($conn, $namaTabel) {
    $result = mysqli_query($conn, "SELECT * FROM $namaTabel");
    $kolom = getKolom($conn, $namaTabel);

    echo "<div class='card shadow-sm mb-5'>";
    echo "<div class='card-body'>";
    echo "<h5 id='$namaTabel' class='card-title mb-3'>📋 Data " . ucfirst($namaTabel) . "</h5>";
    echo "<button class='btn btn-success mb-3' type='button' data-bs-toggle='collapse' data-bs-target='#form_$namaTabel'>➕ Tambah Data</button>";

    echo "<div class='collapse mb-4' id='form_$namaTabel'>";
    echo "<div class='card card-body'>";
    echo "<form method='POST' action='Create/Fungsi/$namaTabel.php'>";

    foreach ($kolom as $i => $col) {
        if ($i == 0) continue;

        echo "<div class='mb-3'>";
        echo "<label class='form-label'>" . ucfirst($col) . "</label>";

        switch ($col) {
            case 'id_menu':
                $menus = getMenuOptions($conn);
                echo "<select class='form-select' name='id_menu' id='id_menu_$namaTabel' required>";
                echo "<option value=''>-- Pilih ID Menu --</option>";
                foreach ($menus as $menu) {
                    echo "<option value='{$menu['id_menu']}' data-nama='{$menu['nama_menu']}'>{$menu['id_menu']}</option>";
                }
                echo "</select>";
                break;

            case 'nama_menu':
                echo "<input type='text' class='form-control' name='nama_menu' id='nama_menu_$namaTabel' readonly>";
                break;

            case 'id_kategori':
                $kategori = getKategoriOptions($conn);
                echo "<select class='form-select' name='id_kategori' id='id_kategori_$namaTabel' required>";
                echo "<option value=''>-- Pilih ID Kategori --</option>";
                foreach ($kategori as $kat) {
                    echo "<option value='{$kat['id_kategori']}' data-nama='{$kat['nama_kategori']}'>{$kat['id_kategori']} - {$kat['nama_kategori']}</option>";
                }
                echo "</select>";
                break;

            case 'nama_kategori':
                echo "<input type='text' class='form-control' name='nama_kategori' id='nama_kategori_$namaTabel' readonly>";
                break;

            case 'id_pesanan':
                if ($namaTabel === 'pembayaran') {
                    $pesananOptions = getPesananOptionsWithHarga($conn);
                    echo "<select class='form-select' name='id_pesanan' id='id_pesanan_$namaTabel' required>";
                    echo "<option value=''>-- Pilih ID Pesanan --</option>";
                    foreach ($pesananOptions as $row) {
                        echo "<option value='{$row['id_pesanan']}' data-harga='{$row['harga']}'>{$row['id_pesanan']}</option>";
                    }
                    echo "</select>";
                    break;
                }
                // default jika bukan pembayaran
                $type = 'text';
                echo "<input type='$type' class='form-control' name='$col' required>";
                break;

            case 'total':
                if ($namaTabel === 'pembayaran') {
                    echo "<input type='text' class='form-control' name='total' id='total_$namaTabel' readonly>";
                    break;
                }
                echo "<input type='text' class='form-control' name='$col' required>";
                break;

            case 'id_pelanggan':
                if ($namaTabel === 'pesanan') {
                    $pelangganOptions = getPelangganOptions($conn);
                    echo "<select class='form-select' name='id_pelanggan' id='id_pelanggan_$namaTabel' required>";
                    echo "<option value=''>-- Pilih ID Pelanggan --</option>";
                    foreach ($pelangganOptions as $pel) {
                        echo "<option value='{$pel['id_pelanggan']}' data-nama='{$pel['nama_pelanggan']}'>{$pel['id_pelanggan']} - {$pel['nama_pelanggan']}</option>";
                    }
                    echo "</select>";
                    break;
                }
                echo "<input type='text' class='form-control' name='$col' required>";
                break;

            case 'metode_pembayaran':
                echo "<select class='form-select' name='metode_pembayaran' required>";
                echo "<option value=''>-- Pilih Metode Pembayaran --</option>";
                echo "<option value='Transfer'>Transfer</option>";
                echo "<option value='Tunai'>Tunai</option>";
                echo "<option value='QRIS'>QRIS</option>";
                echo "<option value='E-Wallet'>E-Wallet</option>";
                echo "</select>";
                break;
            
            case 'status_bayar':
                echo "<input type='text' class='form-control' name='status_bayar' value='Belum Lunas' readonly>";
                break;

            default:
                $type = stripos($col, 'tanggal') !== false ? 'date' : 'text';
                echo "<input type='$type' class='form-control' name='$col' required>";
                break;
        }

        echo "</div>";
    }

    echo "<button type='submit' class='btn btn-primary'>💾 Simpan</button>";
    echo "</form>";
    echo "</div></div>";

    if (!$result || mysqli_num_rows($result) == 0) {
        echo "<div class='alert alert-warning'>Data tidak tersedia.</div>";
    } else {
        echo "<div class='table-responsive'>";
        echo "<table class='table table-bordered table-hover'>";
        echo "<thead class='table-primary'><tr>";
        $columns = array_keys(mysqli_fetch_assoc($result));
        foreach ($columns as $col) {
            echo "<th>" . htmlspecialchars($col) . "</th>";
        }
        echo "<th>Aksi</th></tr></thead>";

        mysqli_data_seek($result, 0);
        echo "<tbody>";
        while ($row = mysqli_fetch_assoc($result)) {
            $id = reset($row);
            echo "<tr>";
            foreach ($row as $value) {
                echo "<td>" . htmlspecialchars($value) . "</td>";
            }
            echo "<td>
                <a href='edit.php?tabel=$namaTabel&id=$id' class='btn btn-warning btn-sm'>✏️ Edit</a>
                <a href='delete.php?tabel=$namaTabel&id=$id' class='btn btn-danger btn-sm' onclick=\"return confirm('Yakin ingin menghapus data ini?')\">🗑 Hapus</a>
            </td></tr>";
        }
        echo "</tbody></table></div>";
    }

    echo "</div></div>";
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Data Gojek - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body.bg-light {
            background: linear-gradient(135deg, #a8edea, #fed6e3);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .header-fixed {
            position: fixed; top: 0; left: 0; right: 0; height: 70px;
            background: linear-gradient(45deg, #007bff, #6610f2);
            display: flex; align-items: center; justify-content: space-between;
            padding: 0 30px; color: white; z-index: 1100;
            box-shadow: 0 3px 8px rgba(0,0,0,0.3);
        }
        .header-fixed h2 {
            margin: 0; font-weight: 700; font-size: 1.6rem;
        }
        .btn-back-fixed {
            background: white; color: #6610f2; font-weight: 600;
            border-radius: 8px; padding: 8px 16px; display: flex; gap: 6px;
            text-decoration: none; box-shadow: 0 2px 8px rgba(0,0,0,0.15);
        }
        .btn-back-fixed:hover {
            background: #6610f2; color: white;
        }
        .main-container {
            padding: 90px 30px 30px 30px; max-width: 1200px; margin: 0 auto;
        }
        .card-title { color: #4a148c; font-weight: 600; }
        .btn-success { background: linear-gradient(45deg, #28a745, #218838); border: none; }
        .btn-success:hover { background: linear-gradient(45deg, #218838, #28a745); }
        .btn-warning { background: linear-gradient(45deg, #ffc107, #e0a800); border: none; color: black; }
        .btn-warning:hover { background: linear-gradient(45deg, #e0a800, #ffc107); color: black; }
        .btn-danger { background: linear-gradient(45deg, #dc3545, #bd2130); border: none; }
        .btn-danger:hover { background: linear-gradient(45deg, #bd2130, #dc3545); }
    </style>
</head>
<body class="bg-light">

<header class="header-fixed">
    <h2>📦 Data Sistem Katering</h2>
    <a href="../index.php" class="btn-back-fixed"><i class="bi bi-arrow-left-circle-fill"></i> Kembali</a>
</header>

<div class="main-container">
    <?php foreach ($tabels as $tabel) tampilkanTabel($conn, $tabel); ?>
</div>

<script>
document.addEventListener("DOMContentLoaded", function () {
    <?php foreach ($tabels as $tabel): ?>
    const idMenu<?= $tabel ?> = document.getElementById("id_menu_<?= $tabel ?>");
    const namaMenu<?= $tabel ?> = document.getElementById("nama_menu_<?= $tabel ?>");

    if (idMenu<?= $tabel ?> && namaMenu<?= $tabel ?>) {
        idMenu<?= $tabel ?>.addEventListener("change", function () {
            const selected = this.options[this.selectedIndex];
            namaMenu<?= $tabel ?>.value = selected.getAttribute("data-nama") || "";
        });
    }

    const idKategori<?= $tabel ?> = document.getElementById("id_kategori_<?= $tabel ?>");
    const namaKategori<?= $tabel ?> = document.getElementById("nama_kategori_<?= $tabel ?>");

    if (idKategori<?= $tabel ?> && namaKategori<?= $tabel ?>) {
        idKategori<?= $tabel ?>.addEventListener("change", function () {
            const selected = this.options[this.selectedIndex];
            namaKategori<?= $tabel ?>.value = selected.getAttribute("data-nama") || "";
        });
    }

    <?php if ($tabel == 'pembayaran'): ?>
    const idPesananPembayaran = document.getElementById("id_pesanan_pembayaran");
    const totalPembayaran = document.getElementById("total_pembayaran");

    if (idPesananPembayaran && totalPembayaran) {
        idPesananPembayaran.addEventListener("change", function () {
            const selected = this.options[this.selectedIndex];
            const harga = selected.getAttribute("data-harga") || "";
            totalPembayaran.value = harga;
        });
    }
    <?php endif; ?>

    <?php if ($tabel == 'pesanan'): ?>
    const idPelangganPesanan = document.getElementById("id_pelanggan_pesanan");
    const namaPelangganPesanan = document.getElementById("nama_pelanggan_pesanan");

    if (idPelangganPesanan && namaPelangganPesanan) {
        idPelangganPesanan.addEventListener("change", function () {
            const selected = this.options[this.selectedIndex];
            const nama = selected.getAttribute("data-nama") || "";
            namaPelangganPesanan.value = nama;
        });
    }
    <?php endif; ?>
    <?php endforeach; ?>
});
</script>

<script>
document.addEventListener("DOMContentLoaded", function() {
  const form = document.querySelector("form");
  const noTelpInput = form.querySelector("input[name='no_telp']");

  form.addEventListener("submit", function(e) {
    const noTelp = noTelpInput.value.trim();

    if (!/^08\d{10}$/.test(noTelp)) {
      e.preventDefault();
      alert("Nomor telepon harus dimulai dengan '08' dan terdiri dari 12 digit angka.");
      noTelpInput.focus();
    }
  });
});
</script>

</body>
</html>
