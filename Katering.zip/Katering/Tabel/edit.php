<?php
require_once '../koneksi.php';

$tabel = $_GET['tabel'] ?? '';
$id = $_GET['id'] ?? '';

if (!$tabel || !$id) {
    die("Data tidak ditemukan.");
}

function getOptions($conn, $query) {
    $result = mysqli_query($conn, $query);
    $options = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $options[] = $row;
    }
    return $options;
}

$data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM $tabel WHERE " . mysqli_fetch_field_direct(mysqli_query($conn, "SELECT * FROM $tabel"), 0)->name . " = '$id'"));
$primaryKey = array_keys($data)[0];

$menus = getOptions($conn, "SELECT id_menu, nama_menu FROM menu");
$kategoris = getOptions($conn, "SELECT id_kategori, nama_kategori FROM kategori");
$pelanggans = getOptions($conn, "SELECT id_pelanggan, nama_pelanggan FROM pelanggan");
$pesanans = getOptions($conn, "SELECT p.id_pesanan, m.harga FROM pesanan p JOIN menu m ON p.id_menu = m.id_menu ORDER BY p.id_pesanan ASC");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $update = [];
    foreach ($_POST as $key => $value) {
        $update[] = "$key='" . mysqli_real_escape_string($conn, $value) . "'";
    }
    $sql = "UPDATE $tabel SET " . implode(", ", $update) . " WHERE $primaryKey = '$id'";
    mysqli_query($conn, $sql);
    header("Location: Read.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Data - <?= ucfirst($tabel) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <h4 class="mb-0">Edit Data - <?= ucfirst($tabel) ?></h4>
        </div>
        <div class="card-body">
            <form method="post" id="form_edit">
                <?php foreach ($data as $field => $value): ?>
                    <div class="mb-3">
                        <label for="<?= $field ?>" class="form-label"><?= ucfirst(str_replace('_', ' ', $field)) ?></label>

                        <?php if ($field === $primaryKey): ?>
                            <input type="text" class="form-control bg-light" name="<?= $field ?>" value="<?= htmlspecialchars($value) ?>" readonly>

                        <?php elseif ($field === 'id_menu'): ?>
                            <select class="form-select" name="id_menu" id="id_menu">
                                <option value="">-- Pilih ID Menu --</option>
                                <?php foreach ($menus as $m): ?>
                                    <option value="<?= $m['id_menu'] ?>" data-nama="<?= $m['nama_menu'] ?>" <?= $value == $m['id_menu'] ? 'selected' : '' ?>>
                                        <?= $m['id_menu'] ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>

                        <?php elseif ($field === 'nama_menu'): ?>
                            <input type="text" class="form-control" name="nama_menu" id="nama_menu" value="<?= htmlspecialchars($value) ?>" readonly>

                        <?php elseif ($field === 'id_kategori'): ?>
                            <select class="form-select" name="id_kategori" id="id_kategori">
                                <option value="">-- Pilih ID Kategori --</option>
                                <?php foreach ($kategoris as $k): ?>
                                    <option value="<?= $k['id_kategori'] ?>" data-nama="<?= $k['nama_kategori'] ?>" <?= $value == $k['id_kategori'] ? 'selected' : '' ?>>
                                        <?= $k['id_kategori'] ?> - <?= $k['nama_kategori'] ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>

                        <?php elseif ($field === 'nama_kategori'): ?>
                            <input type="text" class="form-control" name="nama_kategori" id="nama_kategori" value="<?= htmlspecialchars($value) ?>" readonly>

                        <?php elseif ($field === 'id_pesanan' && $tabel === 'pembayaran'): ?>
                            <input type="text" class="form-control bg-light" name="id_pesanan" id="id_pesanan" value="<?= htmlspecialchars($value) ?>" readonly>

                        <?php elseif ($field === 'total' && $tabel === 'pembayaran'): ?>
                            <input type="text" class="form-control" name="total" id="total" value="<?= htmlspecialchars($value) ?>" readonly>

                        <?php elseif ($field === 'id_pelanggan' && $tabel === 'pesanan'): ?>
                            <select class="form-select" name="id_pelanggan" id="id_pelanggan">
                                <option value="">-- Pilih ID Pelanggan --</option>
                                <?php foreach ($pelanggans as $p): ?>
                                    <option value="<?= $p['id_pelanggan'] ?>" data-nama="<?= $p['nama_pelanggan'] ?>" <?= $value == $p['id_pelanggan'] ? 'selected' : '' ?>>
                                        <?= $p['id_pelanggan'] ?> - <?= $p['nama_pelanggan'] ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>

                        <?php elseif ($field === 'metode_pembayaran'): ?>
                            <select class="form-select" name="metode_pembayaran">
                                <?php
                                $methods = ['Transfer', 'Tunai', 'QRIS', 'E-Wallet'];
                                foreach ($methods as $method):
                                ?>
                                    <option value="<?= $method ?>" <?= $value === $method ? 'selected' : '' ?>><?= $method ?></option>
                                <?php endforeach; ?>
                            </select>

                        <?php elseif ($field === 'status_bayar'): ?>
                            <input type="text" class="form-control" name="status_bayar" value="<?= htmlspecialchars($value) ?>" readonly>

                        <?php else:
                            $type = stripos($field, 'tanggal') !== false ? 'date' : 'text'; ?>
                            <input type="<?= $type ?>" class="form-control" name="<?= $field ?>" value="<?= htmlspecialchars($value) ?>" <?= $field === 'no_telp' ? 'id="no_telp"' : '' ?>>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
                <button type="submit" class="btn btn-success w-100">💾 Simpan Perubahan</button>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", function () {
    const idMenu = document.getElementById("id_menu");
    const namaMenu = document.getElementById("nama_menu");
    if (idMenu && namaMenu) {
        idMenu.addEventListener("change", function () {
            namaMenu.value = this.selectedOptions[0]?.dataset.nama || '';
        });
    }

    const idKategori = document.getElementById("id_kategori");
    const namaKategori = document.getElementById("nama_kategori");
    if (idKategori && namaKategori) {
        idKategori.addEventListener("change", function () {
            namaKategori.value = this.selectedOptions[0]?.dataset.nama || '';
        });
    }

    const idPesanan = document.getElementById("id_pesanan");
    const total = document.getElementById("total");
    if (idPesanan && total) {
        idPesanan.addEventListener("change", function () {
            total.value = this.selectedOptions[0]?.dataset.harga || '';
        });
    }

    const form = document.getElementById("form_edit");
    const noTelp = document.getElementById("no_telp");
    if (form && noTelp) {
        form.addEventListener("submit", function (e) {
            const val = noTelp.value.trim();
            if (!val.startsWith("08") || val.length !== 12) {
                e.preventDefault();
                alert("Nomor telepon harus dimulai dengan '08' dan terdiri dari 12 digit.");
                noTelp.focus();
            }
        });
    }
});
</script>
</body>
</html>
