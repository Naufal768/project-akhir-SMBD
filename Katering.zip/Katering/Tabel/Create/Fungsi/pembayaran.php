<?php
include '../../../koneksi.php';


$metode_pembayaran = $_POST['metode_pembayaran'];
$total = $_POST['total']; 
$status_bayar = $_POST['status_bayar'];
$id_pesanan = $_POST['id_pesanan']; 


$query = "INSERT INTO pembayaran (metode_pembayaran, total, status_bayar, id_pesanan) VALUES ('$metode_pembayaran', '$total', '$status_bayar', '$id_pesanan')";
if (mysqli_query($conn, $query)) {
    header("Location:../../Read.php");
} else {
    echo "Gagal menambahkan data: " . mysqli_error($conn);
}
?>
