<?php
include '../../../koneksi.php';

$nama_menu = $_POST['nama_menu'];
$harga = $_POST['harga'];
$id_kategori = $_POST['id_kategori'];  

$query = "INSERT INTO menu (nama_menu, harga, id_kategori) VALUES ('$nama_menu', '$harga', '$id_kategori')";
if (mysqli_query($conn, $query)) {
    header("Location:../../Read.php");
} else {
    echo "Gagal menambahkan data: " . mysqli_error($conn);
}
?>
