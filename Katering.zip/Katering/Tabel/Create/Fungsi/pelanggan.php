<?php
include '../../../koneksi.php';

$nama = $_POST['nama_pelanggan'];
$alamat = $_POST['alamat'];
$no_telp = $_POST['no_telp'];

$query = "INSERT INTO pelanggan (nama_pelanggan, alamat, no_telp) VALUES ('$nama', '$alamat', '$no_telp')";
if (mysqli_query($conn, $query)) {
    header("Location:../../Read.php");
} else {
    echo "Gagal menambahkan data: " . mysqli_error($conn);
}
?>
