<?php
include '../../../koneksi.php';

$nama_kategori = $_POST['nama_kategori'];

$query = "INSERT INTO kategori (nama_kategori) VALUES ('$nama_kategori')";
if (mysqli_query($conn, $query)) {
    header("Location:../../Read.php");
} else {
    echo "Gagal menambahkan data: " . mysqli_error($conn);
}
?>
