<?php
include '../../../koneksi.php';

// Sesuaikan nama input sesuai kolom di tabel pesanan
$id_pelanggan = $_POST['id_pelanggan'];  // contoh fk dari pelanggan
$id_menu = $_POST['id_menu']; 
$nama_menu = $_POST['nama_menu']; 
$tanggal = $_POST['tanggal']; 

$query = "INSERT INTO pesanan (id_pelanggan, id_menu, nama_menu, tanggal) VALUES ('$id_pelanggan', '$id_menu', '$nama_menu', '$tanggal')";
if (mysqli_query($conn, $query)) {
    header("Location:../../Read.php");
} else {
    echo "Gagal menambahkan data: " . mysqli_error($conn);
}
?>
