<?php
include '../koneksi.php';

$tabels = [
    'view_pembayaran_lengkap',
    'view_pesanan_belum_lunas',
    'view_pesanan_hari_ini',
    'view_menu_terlaris',
    'view_pelanggan_aktif'
];

function tampilkanTabel($conn, $namaTabel) {
    $result = mysqli_query($conn, "SELECT * FROM $namaTabel");

    echo "<div class='card shadow-sm mb-5'>";
    echo "<div class='card-body'>";
    echo "<h5 id='$namaTabel' class='card-title mb-3'>📋 Data " . ucfirst(str_replace('_', ' ', $namaTabel)) . "</h5>";

    if (!$result || mysqli_num_rows($result) == 0) {
        echo "<div class='alert alert-warning'>Data tidak tersedia.</div>";
    } else {
        echo "<div class='table-responsive'>";
        echo "<table class='table table-bordered table-hover'>";
        echo "<thead class='table-dark text-center'><tr>";
        $columns = array_keys(mysqli_fetch_assoc($result));
        foreach ($columns as $col) {
            echo "<th>" . htmlspecialchars($col) . "</th>";
        }
        mysqli_data_seek($result, 0);
        echo "</tr></thead><tbody>";
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            foreach ($row as $value) {
                echo "<td>" . htmlspecialchars($value) . "</td>";
            }
            echo "</tr>";
        }
        echo "</tbody></table></div>";
    }

    echo "</div></div>";
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Data Katering - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600&family=Open+Sans&display=swap" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(to right, #f0f0f0, #e0e0e0);
            font-family: 'Open Sans', sans-serif;
        }
        .sticky-header {
            position: sticky;
            top: 0;
            z-index: 1030;
            background-color: #ffffff;
            padding: 1rem 0.5rem;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
        }
        .sticky-header h2 {
            font-family: 'Playfair Display', serif;
            font-size: 1.8rem;
            margin: 0;
        }
        .table th, .table td {
            vertical-align: middle;
        }
        .btn-success {
            background-color: #198754;
        }
        .card-title {
            font-weight: bold;
        }
    </style>
</head>
<body>

<div class="container py-3">
    <div class="sticky-header d-flex justify-content-between align-items-center mb-4">
        <h2>📦 Data Sistem Katering</h2>
        <a href="../index.php" class="btn btn-outline-dark">🔙 Kembali</a>
    </div>

    <?php
    foreach ($tabels as $tabel) {
        tampilkanTabel($conn, $tabel);
    }
    ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
