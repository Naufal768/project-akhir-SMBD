<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Database Katering - Trinanda Indrayana</title>
  <!-- Bootstrap 5 CDN -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Bootstrap Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600&family=Dancing+Script:wght@600&display=swap" rel="stylesheet">

  <style>
    body {
      background: linear-gradient(to right, #a770ef, #cf8bf3, #fdb99b);
      min-height: 100vh;
      font-family: 'Segoe UI', sans-serif;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    h2 {
      font-family: 'Playfair Display', serif;
      font-size: 2.5rem;
      color: #fff;
    }
    .highlighted-name {
      font-family: 'Dancing Script', cursive;
      font-size: 2rem;
      color: #ffeb3b;
    }
    .card {
      border: none;
      border-radius: 1.25rem;
      transition: all 0.3s ease;
      background: #ffffffcc;
      backdrop-filter: blur(10px);
    }
    .card:hover {
      transform: translateY(-7px);
      box-shadow: 0 12px 30px rgba(0, 0, 0, 0.25);
    }
    .card-body i {
      font-size: 3rem;
      color: #6610f2;
      transition: transform 0.3s ease;
    }
    .card:hover i {
      transform: scale(1.2);
    }
    .card-title {
      font-weight: bold;
      font-size: 1.3rem;
    }
  </style>
</head>
<body>

  <div class="container text-center py-5">
    <h2 class="mb-4">📊 Database Katering </h2>
    
    <div class="row g-4 justify-content-center mt-4">
      <!-- Card 1 -->
      <div class="col-md-4">
        <a href="Tabel/Read.php" class="text-decoration-none text-dark">
          <div class="card p-4 shadow-sm">
            <div class="card-body">
              <i class="bi bi-table"></i>
              <h5 class="card-title mt-3">Tabel</h5>
              <p class="card-text">Klik untuk melihat semua tabel katering.</p>
            </div>
          </div>
        </a>
      </div>

      <!-- Card 2 -->
      <div class="col-md-4">
        <a href="View/Read.php" class="text-decoration-none text-dark">
          <div class="card p-4 shadow-sm">
            <div class="card-body">
              <i class="bi bi-eye-fill"></i>
              <h5 class="card-title mt-3">View</h5>
              <p class="card-text">Klik untuk melihat semua view dari database katering.</p>
            </div>
          </div>
        </a>
      </div>

      <!-- Card 3 -->
      <div class="col-md-4">
        <a href="Stored Procedure/index.php" class="text-decoration-none text-dark">
          <div class="card p-4 shadow-sm">
            <div class="card-body">
              <i class="bi bi-gear-fill"></i>
              <h5 class="card-title mt-3">Stored Procedure</h5>
              <p class="card-text">Klik untuk melakukan uji prosedur tersimpan.</p>
            </div>
          </div>
        </a>
      </div>
    </div>
  </div>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
